Hello,
Thank you for downloading the Eldes Cordel font from DaFont site.
Highly appreciated that  you took a few minutes to read this one.

...

NOTE: This DEMO FONT is free for PERSONAL USE ONLY!

Link to the FULL VERSION of the font and for COMMERCIAL USE:
https://eldes.com/font-eldes-cordel

...

What is a DEMO FONT?

It is a partial version of the font, distributed by third party sites.
I believe that everyone should be allowed to test-drive a font before they purchase it.
A more or less fully working demo font is a good way to do just that.
A demo font, a more or less fully working font version, is a good way to do just that.

...

What is PERSONAL USE?

For this font, personal use is considered to be any use that:
- does NOT generate direct or indirect financial compensation;
- does NOT aim at professional promotion, directly or indirectly;
- does NOT aim to raise funds;
- is NOT published in communication channels, including social media;
- etc.

Examples of personal use of the font:
- in the art of decoration, invitation and/or souvenirs of your child's birthday party;
- in the print of a T-shirt for personal wear;
- in printed posters for your room's decoration;
- in the assignment and/or projects of middle and high school students;
- etc.

(if you're still unsure, feel free to message me)

For others uses, please purchase a license at my site (link above).
[ Typography is a work. As type designer I make a living creating and selling fonts. ]

...

Can I use this demo font for my LOGO?

YES, you can.
Provided you use it according to the rules specified above for personal use.
For other uses just purchase a license.
Do note that you can only trademark/copyright the DESIGN of the logo, not the font used, as the copyright of my fonts belongs to me.

(if you're still unsure, feel free to message me)

...

Can I use this font for my YOUTUBE channel?

YES, you can - but ONLY if you purchase a license.
You cannot use this demo font for YouTube channels or other communication channels.

(if you're still unsure, feel free to message me)

...

Can I use this font for my SOCIAL MEDIA account?

Again, you can use my fonts for any social media account, as long as you purchase the appropriate license.
You cannot use this demo font for your Facebook, Instagram, Twitter or whatever account.

(if you're still unsure, feel free to message me)

...

Can I use this font for my GAME?

You cannot use this demo font for your apps, games and software.
You will need to purchase the appropriate license.

(if you're still unsure, feel free to message me)

...

Can I use this demo font in the DESIGN or DRAFT to be approved by my client?

YES, you can.
But if your design was approved, then purchase a license before using it commercially.

(if you're still unsure, feel free to message me)

...

I used this demo font commercially! What now?

Well, I am sure you used a demo font commercially because you didn't know you should have purchased a license.
Contact my agency (contact@salander.agency) and I’m sure we’ll work something out.

...

Are you still confuse?
Any problems or questions, please contact me:
studio@eldes.com

Thanks,

ELDES